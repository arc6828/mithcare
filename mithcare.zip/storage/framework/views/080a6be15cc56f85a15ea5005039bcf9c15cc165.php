<?php $__env->startSection('content'); ?>
<div class="row mt-5">
  <div class="col-xl-12 mb-5 mb-xl-0">
    <div class="card shadow">
      <div class="card-header border-0">
        <div class="row align-items-center">
          <div class="col">
            <h3 class="mb-0">Patient</h3>
          </div>
          <div class="col text-right">
            <a href="#!" class="btn btn-sm btn-primary">New</a>
          </div>
        </div>
      </div>
      <div class="table-responsive" style="padding:20px;">
        <!-- Patient table -->
        <table class="table align-items-center table-flush" id="table-patient">

        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('optional-js'); ?>
<script src="<?php echo e(url('/')); ?>/theme-argon/assets/vendor/clipboard/dist/clipboard.min.js"></script>
<script>
  $(document).ready(function() {
    var dataSet = [];
    //console.log('<?php echo json_encode($table_patient, 15, 512) ?>');
    var patients = JSON.parse('<?php echo json_encode($table_patient, 15, 512) ?>');
    console.log(patients);
    patients.forEach(function(element, index){
      dataSet.push([
        element.patient_id,
        '<a href="<?php echo e(url('/')); ?>/user/patient/'+element.patient_id+'">'+element.patient_name+'</a>',
        element.gender,
        element.date_of_birth,
      ]);
    });
    $('#table-patient').DataTable({
      data: dataSet,
      columns: [
          { title: "Patient id" },
          { title: "Patient name" },
          { title: "Gender" },
          //{ title: "Blood type" },
          //{ title: "Citizen ID" },
          { title: "Birthday" },
          //{ title: "Age" },
          //{ title: "Address" },
          //{ title: "Phone" },
          //{ title: "Medical condition" },
          //{ title: "Drug allergy" }
      ],
    });
  } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout/default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>