<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PatientModel extends Model
{
    //
  protected $table = 'patients';
  protected $primaryKey = 'patient_id';
}
